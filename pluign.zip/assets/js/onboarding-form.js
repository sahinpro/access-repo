/**
 * Onboarding Form – multi-step wizard behaviour.
 * Step count is calculated from the rendered panes; nothing is hardcoded.
 */
class OnboardingFormHandler extends elementorModules.frontend.handlers.Base {
    getDefaultSettings() {
        return {
            selectors: {
                wrapper: '.of-8c4c4dfe-wrapper',
                form: '.of-8c4c4dfe-form',
                stepItem: '.of-8c4c4dfe-step-item',
                stepPane: '.of-8c4c4dfe-step-pane',
                fieldWrap: '.of-8c4c4dfe-field-wrap',
                input: '.of-8c4c4dfe-input',
                fieldError: '.of-8c4c4dfe-field-error',
                btnNext: '.of-8c4c4dfe-btn-next',
                btnPrev: '.of-8c4c4dfe-btn-prev',
                btnSubmit: '.of-8c4c4dfe-btn-submit',
                message: '.of-8c4c4dfe-message',
                progressLine: '.of-8c4c4dfe-progress-line',
                topProgress: '.of-8c4c4dfe-top-progress-fill'
            }
        };
    }

    getDefaultElements() {
        const selectors = this.getSettings('selectors');
        return {
            $wrapper: this.$element.find(selectors.wrapper),
            $form: this.$element.find(selectors.form),
            $stepItems: this.$element.find(selectors.stepItem),
            $stepPanes: this.$element.find(selectors.stepPane),
            $message: this.$element.find(selectors.message),
            $progressLine: this.$element.find(selectors.progressLine),
            $topProgress: this.$element.find(selectors.topProgress)
        };
    }

    bindEvents() {
        const s = this.getSettings('selectors');

        this.elements.$form.on('click', s.btnNext, this.onNextStep.bind(this));
        this.elements.$form.on('click', s.btnPrev, this.onPrevStep.bind(this));
        this.elements.$form.on('submit', this.onSubmit.bind(this));
        this.elements.$form.on('keydown', s.input, this.onKeydown.bind(this));
        this.elements.$form.on('input change', s.input, (event) => {
            this.clearFieldError(jQuery(event.target));
        });
        this.elements.$stepItems.on('click', (event) => {
            const index = Number.parseInt(jQuery(event.currentTarget).attr('data-step'), 10);
            // Only navigate back to already completed steps.
            if (jQuery(event.currentTarget).hasClass('completed')) {
                this.goToStep(index);
            }
        });

        this.goToStep(0);
    }

    getStepCount() {
        return this.elements.$stepPanes.length;
    }

    onKeydown(event) {
        // Enter advances the step (or submits on the last step), except inside
        // multiline inputs where Enter must keep inserting line breaks.
        if (event.key !== 'Enter' || event.shiftKey) return;

        const $target = jQuery(event.target);
        if ($target.is('textarea') || $target.attr('contenteditable') === 'true') return;

        event.preventDefault();

        const $pane = $target.closest('.of-8c4c4dfe-step-pane');
        const $next = $pane.find('.of-8c4c4dfe-btn-next');
        if ($next.length) {
            $next.trigger('click');
        } else {
            // Native click on the submit button routes through the form's
            // submit handler once – no manual $form.trigger('submit') here.
            $pane.find('.of-8c4c4dfe-btn-submit').trigger('click');
        }
    }

    onNextStep(event) {
        event.preventDefault();
        const $currentPane = jQuery(event.currentTarget).closest('.of-8c4c4dfe-step-pane');

        if (!this.validatePane($currentPane)) return;

        this.goToStep(Number.parseInt($currentPane.attr('data-step'), 10) + 1);
    }

    onPrevStep(event) {
        event.preventDefault();
        const $currentPane = jQuery(event.currentTarget).closest('.of-8c4c4dfe-step-pane');
        this.goToStep(Number.parseInt($currentPane.attr('data-step'), 10) - 1);
    }

    validatePane($pane) {
        let isValid = true;

        $pane.find(this.getSettings('selectors').input).each(function () {
            const input = this;

            if (input.value.trim() === '' && !input.required) {
                return; // Optional empty fields always pass.
            }

            let message = '';

            if (input.required && input.value.trim() === '') {
                message = 'This field is required.';
            } else if (typeof input.checkValidity === 'function' && !input.checkValidity()) {
                if (input.type === 'email') {
                    message = 'Please enter a valid email address.';
                } else if (input.type === 'url') {
                    message = 'Please enter a valid URL (including https://).';
                } else if (input.type === 'tel') {
                    message = 'Please enter a valid phone number.';
                } else if (input.type === 'number') {
                    message = 'Please enter a valid number.';
                } else {
                    message = input.validationMessage || 'Invalid value.';
                }
            }

            if (message) {
                this.showFieldError(jQuery(input), message);
                if (isValid) {
                    input.focus();
                }
                isValid = false;
            }
        });

        return isValid;
    }

    showFieldError($input, message) {
        const $wrap = $input.closest(this.getSettings('selectors').fieldWrap);
        $wrap.addClass('has-error');
        $input.addClass('of-8c4c4dfe-input-invalid');
        $wrap.find(this.getSettings('selectors').fieldError).text(message);
    }

    clearFieldError($input) {
        const $wrap = $input.closest(this.getSettings('selectors').fieldWrap);
        $wrap.removeClass('has-error');
        $input.removeClass('of-8c4c4dfe-input-invalid');
        $wrap.find(this.getSettings('selectors').fieldError).text('');
    }

    goToStep(index) {
        const total = this.getStepCount();
        if (index < 0 || index >= total) return;

        this.elements.$stepPanes.removeClass('active');
        this.elements.$stepPanes.filter(`[data-step="${index}"]`).addClass('active');

        this.elements.$stepItems.each(function () {
            const stepIndex = Number.parseInt(jQuery(this).attr('data-step'), 10);
            jQuery(this).removeClass('active completed is-navigable');
            if (stepIndex < index) {
                jQuery(this).addClass('completed is-navigable');
            } else if (stepIndex === index) {
                jQuery(this).addClass('active');
            }
        });

        this.updateProgress(index, total);
    }

    updateProgress(activeIndex, total) {
        if (total <= 1) {
            this.elements.$progressLine.css('height', '0');
            this.elements.$wrapper.get(0)?.style.setProperty('--ofe-progress', '1');
            return;
        }

        const percentage = Math.min((activeIndex / (total - 1)) * 100, 100);
        this.elements.$progressLine.css('height', `${percentage}%`);

        // Thin top progress bar reflects completion of the whole form.
        const completion = (activeIndex / total) * 100;
        this.elements.$wrapper.get(0)?.style.setProperty('--ofe-progress', `${completion / 100}`);
    }

    collectStepData() {
        const selectors = this.getSettings('selectors');
        const steps = [];

        this.elements.$stepPanes.each(function (index) {
            const $pane = jQuery(this);
            const step = {
                label: $pane.find('.of-8c4c4dfe-pane-title').first().text().trim(),
                fields: []
            };

            $pane.find(selectors.input).each(function () {
                const $input = jQuery(this);
                step.fields.push({
                    key: ($input.attr('name') || '').replace(/^ofe_/, ''),
                    label: $input.data('label') || $input.attr('name') || '',
                    type: $input.attr('type') || $input.data('type') || 'text',
                    value: $input.val()
                });
            });

            steps[index] = step;
        });

        return steps;
    }

    buildSubmitPayload(steps) {
        // Explicit bracket keys keep empty-string values (jQuery strips nulls
        // in recursive object serialization) and PHP parses them back into
        // nested arrays natively.
        const data = {
            action: 'onboarding_form_submit_8c4c4dfe',
            nonce: OnboardingForm8c4c4dfe.nonce,
            email_to: this.elements.$form.data('to') || '',
            email_subject: this.elements.$form.data('subject') || ''
        };

        steps.forEach((step, si) => {
            data[`steps[${si}][label]`] = step.label;
            step.fields.forEach((field, fi) => {
                data[`steps[${si}][fields][${fi}][key]`] = field.key;
                data[`steps[${si}][fields][${fi}][label]`] = field.label;
                data[`steps[${si}][fields][${fi}][type]`] = field.type;
                data[`steps[${si}][fields][${fi}][value]`] = field.value == null ? '' : String(field.value);
            });
        });

        return data;
    }

    onSubmit(event) {
        event.preventDefault();

        const $form = this.elements.$form;
        const $message = this.elements.$message;
        const $submitButton = $form.find(this.getSettings('selectors').btnSubmit);
        const originalHtml = $submitButton.html();

        // Validate every pane before submitting; jump to the first invalid one.
        let allValid = true;
        let firstInvalid = null;
        const self = this;
        $form.find(this.getSettings('selectors').stepPane).each(function () {
            if (allValid) {
                allValid = self.validatePane(jQuery(this));
                if (!allValid) firstInvalid = this;
            }
        });

        if (!allValid) {
            if (firstInvalid) {
                this.goToStep(Number.parseInt(jQuery(firstInvalid).attr('data-step'), 10));
            }
            return;
        }

        $submitButton.prop('disabled', true).text('Sending...');
        $message.empty();

        jQuery.ajax({
            url: OnboardingForm8c4c4dfe.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: this.buildSubmitPayload(this.collectStepData())
        }).done((response) => {
            if (response && response.success) {
                jQuery('<p>', { class: 'ofe-success', text: response.data.message }).appendTo($message);
                $form[0].reset();
                this.goToStep(0);
            } else {
                const errorText = response && response.data && response.data.message
                    ? response.data.message
                    : 'Unable to submit the form. Please try again.';
                jQuery('<p>', { class: 'ofe-error', text: errorText }).appendTo($message);
            }
        }).fail(() => {
            jQuery('<p>', { class: 'ofe-error', text: 'An error occurred. Please try again.' }).appendTo($message);
        }).always(() => {
            $submitButton.prop('disabled', false).html(originalHtml || 'Submit');
        });
    }
}

jQuery(window).on('elementor/frontend/init', () => {
    elementorFrontend.hooks.addAction('frontend/element_ready/onboarding_form_8c4c4dfe.default', ($element) => {
        elementorFrontend.elementsHandler.addHandler(OnboardingFormHandler, { $element });
    });
});
