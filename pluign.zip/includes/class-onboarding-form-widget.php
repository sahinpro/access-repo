<?php
namespace AngieSnippets;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Onboarding_Form_8c4c4dfe extends \Elementor\Widget_Base {

    const ID_PREFIX = 'of-8c4c4dfe';

    public function get_name() {
        return 'onboarding_form_8c4c4dfe';
    }

    public function get_title() {
        return esc_html__( 'Onboarding Form', 'onboarding-form-elementor' );
    }

    public function get_icon() {
        return 'eicon-form-horizontal';
    }

    public function get_categories() {
        return [ 'angie-widgets', 'general' ];
    }

    public function get_script_depends() {
        return [ 'onboarding-form-script-8c4c4dfe' ];
    }

    public function get_style_depends() {
        return [ 'onboarding-form-style-8c4c4dfe' ];
    }

    /**
     * Convert a setting into a unique, stable form field name.
     * Submission data is keyed by this identifier instead of the label so
     * duplicate labels never overwrite each other.
     */
    private function make_field_key( $field ) {
        if ( ! empty( $field['field_key'] ) ) {
            return sanitize_key( str_replace( '-', '_', $field['field_key'] ) );
        }

        $title = ! empty( $field['field_label'] ) ? $field['field_label'] : 'field';
        $base  = sanitize_key( str_replace( '-', '_', sanitize_title( $title ) ) );

        return $base !== '' ? $base . '_' . substr( md5( (string) $field['_id'] . $title ), 0, 6 ) : 'ofe_' . $field['_id'];
    }

    /**
     * Group repeater rows into steps. Fields that appear before the first
     * step separator are never discarded – they are collected into an
     * implicit leading step so removing a step can never silently remove
     * inputs from the form.
     */
    private function build_steps( array $fields ) {
        $steps  = [];
        $orphan = [];

        foreach ( $fields as $field ) {
            $type = isset( $field['field_type'] ) ? $field['field_type'] : 'text';

            if ( 'step' === $type ) {
                $steps[] = [
                    'type'    => 'step',
                    'label'   => isset( $field['field_label'] ) ? $field['field_label'] : '',
                    'desc'    => isset( $field['step_description'] ) ? $field['step_description'] : '',
                    'icon'    => isset( $field['step_icon'] ) ? $field['step_icon'] : [],
                    'fields'  => [],
                    '_id'     => isset( $field['_id'] ) ? $field['_id'] : '',
                ];
            } elseif ( ! empty( $steps ) ) {
                $steps[ count( $steps ) - 1 ]['fields'][] = $field;
            } else {
                $orphan[] = $field;
            }
        }

        if ( ! empty( $orphan ) ) {
            array_unshift( $steps, [
                'type'   => 'step',
                'label'  => __( 'Details', 'onboarding-form-elementor' ),
                'desc'   => '',
                'icon'   => [],
                'fields' => $orphan,
                '_id'    => 'implicit',
            ] );
        }

        return $steps;
    }

    protected function register_controls() {
        $this->register_content_controls();
        $this->register_style_controls();
    }

    private function register_content_controls() {
        $this->start_controls_section(
            'section_form_content',
            [
                'label' => esc_html__( 'Form Content', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'intro_heading',
            [
                'label'       => esc_html__( 'Intro Heading', 'onboarding-form-elementor' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Get Your Business Set Up!', 'onboarding-form-elementor' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'intro_description',
            [
                'label'   => esc_html__( 'Intro Description', 'onboarding-form-elementor' ),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'rows'    => 4,
                'default' => esc_html__( "We'll use these details to customize your Smart Referral Hub account and make it easy for your customers to refer friends, leave reviews, share your content, and promote your business. Let's turn customer engagement into business growth!", 'onboarding-form-elementor' ),
            ]
        );

        $this->add_control(
            'form_title',
            [
                'label'       => esc_html__( 'Sidebar Title', 'onboarding-form-elementor' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'New Account Registration', 'onboarding-form-elementor' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'load_default_template',
            [
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label' => esc_html__( 'Load 5-Step Template', 'onboarding-form-elementor' ),
                'label_on' => esc_html__( 'Reset', 'onboarding-form-elementor' ),
                'label_off' => esc_html__( 'Keep', 'onboarding-form-elementor' ),
                'return_value' => 'yes',
                'default' => '',
                'description' => esc_html__( 'Turn on to replace the Fields & Steps repeater with the default 5-step / 16-field onboarding template. Existing saved forms are never changed automatically.', 'onboarding-form-elementor' ),
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'field_type',
            [
                'label'   => esc_html__( 'Type', 'onboarding-form-elementor' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'text',
                'options' => [
                    'step'     => esc_html__( 'Step (Separator)', 'onboarding-form-elementor' ),
                    'text'     => esc_html__( 'Text', 'onboarding-form-elementor' ),
                    'email'    => esc_html__( 'Email', 'onboarding-form-elementor' ),
                    'tel'      => esc_html__( 'Phone (Tel)', 'onboarding-form-elementor' ),
                    'number'   => esc_html__( 'Number', 'onboarding-form-elementor' ),
                    'url'      => esc_html__( 'URL', 'onboarding-form-elementor' ),
                    'textarea' => esc_html__( 'Textarea', 'onboarding-form-elementor' ),
                ],
            ]
        );

        $repeater->add_control(
            'field_label',
            [
                'label'       => esc_html__( 'Label / Step Title', 'onboarding-form-elementor' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Field Label', 'onboarding-form-elementor' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'step_description',
            [
                'label'       => esc_html__( 'Step Description', 'onboarding-form-elementor' ),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'rows'        => 3,
                'default'     => '',
                'placeholder' => esc_html__( 'Optional helper text shown under the step title.', 'onboarding-form-elementor' ),
                'condition'   => [ 'field_type' => 'step' ],
            ]
        );

        $repeater->add_control(
            'help_text',
            [
                'label'       => esc_html__( 'Helper Text / Question Description', 'onboarding-form-elementor' ),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'rows'        => 3,
                'default'     => '',
                'condition'   => [ 'field_type!' => 'step' ],
            ]
        );

        $repeater->add_control(
            'show_label',
            [
                'label'        => esc_html__( 'Show Label', 'onboarding-form-elementor' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'onboarding-form-elementor' ),
                'label_off'    => esc_html__( 'No', 'onboarding-form-elementor' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'    => [ 'field_type!' => 'step' ],
            ]
        );

        $repeater->add_control(
            'placeholder',
            [
                'label'       => esc_html__( 'Placeholder', 'onboarding-form-elementor' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => '',
                'label_block' => true,
                'condition'   => [ 'field_type!' => 'step' ],
            ]
        );

        $repeater->add_control(
            'show_placeholder',
            [
                'label'        => esc_html__( 'Show Placeholder', 'onboarding-form-elementor' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'onboarding-form-elementor' ),
                'label_off'    => esc_html__( 'No', 'onboarding-form-elementor' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'    => [ 'field_type!' => 'step' ],
            ]
        );

        $repeater->add_control(
            'required',
            [
                'label'        => esc_html__( 'Required', 'onboarding-form-elementor' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'onboarding-form-elementor' ),
                'label_off'    => esc_html__( 'No', 'onboarding-form-elementor' ),
                'return_value' => 'yes',
                'default'      => '',
                'condition'    => [ 'field_type!' => 'step' ],
            ]
        );

        // Keep the original setting key so existing widget data remains compatible.
        $repeater->add_control(
            'step_icon',
            [
                'label'   => esc_html__( 'Field / Step Icon', 'onboarding-form-elementor' ),
                'type'    => \Elementor\Controls_Manager::ICONS,
                'default' => [],
            ]
        );

        $repeater->add_control(
            'show_icon',
            [
                'label'        => esc_html__( 'Show Icon', 'onboarding-form-elementor' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'onboarding-form-elementor' ),
                'label_off'    => esc_html__( 'No', 'onboarding-form-elementor' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'    => [ 'field_type!' => 'step' ],
            ]
        );

        $repeater->add_control(
            'field_key',
            [
                'label'       => esc_html__( 'Unique Field Identifier', 'onboarding-form-elementor' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => '',
                'placeholder' => esc_html__( 'e.g. first_name. Auto-generated from the label if empty.', 'onboarding-form-elementor' ),
                'description' => esc_html__( 'Used as the submission key in the email notification.', 'onboarding-form-elementor' ),
                'condition'   => [ 'field_type!' => 'step' ],
            ]
        );

        /**
         * Elementor repeater controls apply their CSS to {{CURRENT_ITEM}}.
         * The matching elementor-repeater-item-{_id} class is printed on each
         * field wrapper in render(). The CSS gap is handled with wrapper
         * padding, not flex column-gap, so percentage widths never exceed 100%.
         */
        $repeater->add_responsive_control(
            'field_width',
            [
                'label'          => esc_html__( 'Column Width', 'onboarding-form-elementor' ),
                'type'           => \Elementor\Controls_Manager::SELECT,
                'default'        => '100',
                'tablet_default' => '100',
                'mobile_default' => '100',
                'options'        => [
                    '100' => '100%',
                    '80'  => '80%',
                    '75'  => '75%',
                    '66'  => '66%',
                    '60'  => '60%',
                    '50'  => '50%',
                    '40'  => '40%',
                    '33'  => '33%',
                    '25'  => '25%',
                    '20'  => '20%',
                ],
                'condition'      => [ 'field_type!' => 'step' ],
                'selectors'      => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'flex: 0 0 {{VALUE}}%; max-width: {{VALUE}}%;',
                ],
            ]
        );

        $this->add_control(
            'form_fields',
            [
                'label'       => esc_html__( 'Fields & Steps', 'onboarding-form-elementor' ),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => $this->get_default_template_rows(),
                'title_field' => '{{{ field_label }}} ({{{ field_type }}})',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_email_settings',
            [
                'label' => esc_html__( 'Email Settings', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'email_to',
            [
                'label'   => esc_html__( 'To Email', 'onboarding-form-elementor' ),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => get_option( 'admin_email' ),
            ]
        );

        $this->add_control(
            'email_subject',
            [
                'label'   => esc_html__( 'Subject', 'onboarding-form-elementor' ),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'New Onboarding Submission', 'onboarding-form-elementor' ),
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Default template: 5 steps, 16 input fields (15 client fields + 1 editable placeholder).
     * Steps are plain repeater separators, so the step count stays fully flexible –
     * removing a step separator never removes the fields themselves.
     */
    private function get_default_template_rows() {
        $icon = function ( $value, $library = 'fa-regular' ) {
            return [ 'value' => $value, 'library' => $library ];
        };

        return [
            // STEP 1 – Business Overview.
            [
                'field_type'       => 'step',
                'field_label'      => esc_html__( 'Business Overview', 'onboarding-form-elementor' ),
                'step_description' => esc_html__( 'Tell us a little about your business.', 'onboarding-form-elementor' ),
                'step_icon'        => $icon( 'far fa-building', 'fa-regular' ),
            ],
            [
                'field_type'  => 'text',
                'field_label' => esc_html__( 'Your First Question', 'onboarding-form-elementor' ),
                'placeholder' => esc_html__( 'Type your answer here...', 'onboarding-form-elementor' ),
                'field_key'   => 'your_first_question',
                'field_width' => '100',
                'required'    => '',
                'step_icon'   => $icon( 'far fa-question-circle', 'fa-regular' ),
            ],

            // STEP 2 – Contact Details.
            [
                'field_type'       => 'step',
                'field_label'      => esc_html__( 'Contact Details', 'onboarding-form-elementor' ),
                'step_description' => esc_html__( 'Share your contact information so we can reach you.', 'onboarding-form-elementor' ),
                'step_icon'        => $icon( 'far fa-address-book', 'fa-regular' ),
            ],
            [
                'field_type'  => 'text',
                'field_label' => esc_html__( 'First Name', 'onboarding-form-elementor' ),
                'field_key'   => 'first_name',
                'required'    => 'yes',
                'field_width' => '50',
                'step_icon'   => $icon( 'far fa-user', 'fa-regular' ),
            ],
            [
                'field_type'  => 'text',
                'field_label' => esc_html__( 'Last Name', 'onboarding-form-elementor' ),
                'field_key'   => 'last_name',
                'required'    => 'yes',
                'field_width' => '50',
            ],
            [
                'field_type'  => 'email',
                'field_label' => esc_html__( 'Email', 'onboarding-form-elementor' ),
                'field_key'   => 'email',
                'required'    => 'yes',
                'field_width' => '50',
                'step_icon'   => $icon( 'far fa-envelope', 'fa-regular' ),
            ],
            [
                'field_type'  => 'tel',
                'field_label' => esc_html__( 'Phone', 'onboarding-form-elementor' ),
                'field_key'   => 'phone',
                'required'    => 'yes',
                'field_width' => '50',
                'step_icon'   => $icon( 'fas fa-phone', 'fa-solid' ),
            ],

            // STEP 3 – Online Presence.
            [
                'field_type'       => 'step',
                'field_label'      => esc_html__( 'Online Presence', 'onboarding-form-elementor' ),
                'step_description' => esc_html__( 'Share your website and business social media profiles.', 'onboarding-form-elementor' ),
                'step_icon'        => $icon( 'fas fa-globe', 'fa-solid' ),
            ],
            [
                'field_type'  => 'url',
                'field_label' => esc_html__( 'Website URL', 'onboarding-form-elementor' ),
                'placeholder' => 'https://',
                'field_key'   => 'website_url',
                'field_width' => '100',
                'step_icon'   => $icon( 'fas fa-globe', 'fa-solid' ),
            ],
            [
                'field_type'  => 'url',
                'field_label' => esc_html__( 'Instagram Business Profile URL', 'onboarding-form-elementor' ),
                'placeholder' => 'https://instagram.com/',
                'field_key'   => 'instagram_profile_url',
                'field_width' => '100',
                'step_icon'   => $icon( 'fab fa-instagram', 'fa-brands' ),
            ],
            [
                'field_type'  => 'url',
                'field_label' => esc_html__( 'Facebook Business Page URL', 'onboarding-form-elementor' ),
                'placeholder' => 'https://facebook.com/',
                'field_key'   => 'facebook_page_url',
                'field_width' => '100',
                'step_icon'   => $icon( 'fab fa-facebook', 'fa-brands' ),
            ],

            // STEP 4 – Reviews & Social Promotion.
            [
                'field_type'       => 'step',
                'field_label'      => esc_html__( 'Reviews & Social Promotion', 'onboarding-form-elementor' ),
                'step_description' => esc_html__( 'Add your review links and social media content that customers can share.', 'onboarding-form-elementor' ),
                'step_icon'        => $icon( 'far fa-star', 'fa-regular' ),
            ],
            [
                'field_type'  => 'url',
                'field_label' => esc_html__( 'Google Review Link', 'onboarding-form-elementor' ),
                'placeholder' => 'https://g.page/r/',
                'field_key'   => 'google_review_link',
                'field_width' => '100',
                'step_icon'   => $icon( 'fab fa-google', 'fa-brands' ),
            ],
            [
                'field_type'  => 'url',
                'field_label' => esc_html__( 'Facebook Reviews Link', 'onboarding-form-elementor' ),
                'placeholder' => 'https://facebook.com/',
                'field_key'   => 'facebook_reviews_link',
                'field_width' => '100',
                'step_icon'   => $icon( 'fab fa-facebook', 'fa-brands' ),
            ],
            [
                'field_type'  => 'url',
                'field_label' => esc_html__( 'Yelp Business Page URL', 'onboarding-form-elementor' ),
                'placeholder' => 'https://yelp.com/biz/',
                'field_key'   => 'yelp_business_url',
                'field_width' => '100',
                'step_icon'   => $icon( 'fab fa-yelp', 'fa-brands' ),
            ],
            [
                'field_type'  => 'url',
                'field_label' => esc_html__( 'Facebook Post or Reel URL', 'onboarding-form-elementor' ),
                'help_text'   => esc_html__( "Provide a link to a Facebook post or Reel you'd like your customers to share with their friends and followers to help promote your business.", 'onboarding-form-elementor' ),
                'placeholder' => 'https://facebook.com/',
                'field_key'   => 'facebook_post_reel_url',
                'field_width' => '100',
                'step_icon'   => $icon( 'fab fa-facebook', 'fa-brands' ),
            ],
            [
                'field_type'  => 'url',
                'field_label' => esc_html__( 'Instagram Post or Reel URL', 'onboarding-form-elementor' ),
                'help_text'   => esc_html__( "Provide a link to an Instagram post or Reel you'd like your customers to share with their friends and followers to help promote your business.", 'onboarding-form-elementor' ),
                'placeholder' => 'https://instagram.com/p/',
                'field_key'   => 'instagram_post_reel_url',
                'field_width' => '100',
                'step_icon'   => $icon( 'fab fa-instagram', 'fa-brands' ),
            ],

            // STEP 5 – Marketing Preferences.
            [
                'field_type'       => 'step',
                'field_label'      => esc_html__( 'Marketing Preferences', 'onboarding-form-elementor' ),
                'step_description' => esc_html__( 'Tell us how you would like your customers to promote your business.', 'onboarding-form-elementor' ),
                'step_icon'        => $icon( 'far fa-bullhorn', 'fa-regular' ),
            ],
            [
                'field_type'  => 'text',
                'field_label' => esc_html__( 'What hashtags would you like customers to include when sharing posts about your business?', 'onboarding-form-elementor' ),
                'placeholder' => esc_html__( 'Type your answer here...', 'onboarding-form-elementor' ),
                'field_key'   => 'hashtags',
                'field_width' => '100',
                'step_icon'   => $icon( 'fas fa-hashtag', 'fa-solid' ),
            ],
            [
                'field_type'  => 'text',
                'field_label' => esc_html__( "Promotional Offer or Incentives your customers actually want.", 'onboarding-form-elementor' ),
                'placeholder' => esc_html__( 'Type your answer here...', 'onboarding-form-elementor' ),
                'field_key'   => 'promotional_offers',
                'field_width' => '100',
                'step_icon'   => $icon( 'far fa-gift', 'fa-regular' ),
            ],
            [
                'field_type'  => 'text',
                'field_label' => esc_html__( "Anything Else You'd Like Us to Know?", 'onboarding-form-elementor' ),
                'placeholder' => esc_html__( 'Type your answer here...', 'onboarding-form-elementor' ),
                'field_key'   => 'anything_else',
                'field_width' => '100',
                'step_icon'   => $icon( 'far fa-comment-dots', 'fa-regular' ),
            ],
        ];
    }

    private function register_style_controls() {
        $this->register_container_styles();
        $this->register_intro_styles();
        $this->register_sidebar_styles();
        $this->register_stepper_styles();
        $this->register_progress_styles();
        $this->register_step_header_styles();
        $this->register_fields_layout_styles();
        $this->register_label_styles();
        $this->register_input_styles();
        $this->register_placeholder_styles();
        $this->register_icon_styles();
        $this->register_divider_styles();
        $this->register_button_styles();
        $this->register_keyboard_hint_styles();
        $this->register_message_styles();
    }

    private function register_container_styles() {
        $this->start_controls_section(
            'section_style_container',
            [
                'label' => esc_html__( 'Main Container', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'container_width',
            [
                'label'      => esc_html__( 'Width', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'      => [ 'px' => [ 'min' => 300, 'max' => 1600 ], '%' => [ 'min' => 30, 'max' => 100 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-wrapper' => 'width: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'container_max_width',
            [
                'label'      => esc_html__( 'Max Width', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'      => [ 'px' => [ 'min' => 300, 'max' => 1600 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-wrapper' => 'max-width: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->add_control(
            'container_bg_color',
            [
                'label'     => esc_html__( 'Background Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-wrapper' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [ 'name' => 'container_border', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-wrapper' ]
        );

        $this->add_responsive_control(
            'container_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [ 'name' => 'container_box_shadow', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-wrapper' ]
        );

        $this->add_responsive_control(
            'container_padding',
            [
                'label'      => esc_html__( 'Padding', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'container_margin',
            [
                'label'      => esc_html__( 'Margin', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->end_controls_section();
    }

    private function register_intro_styles() {
        $this->start_controls_section(
            'section_style_intro',
            [
                'label' => esc_html__( 'Intro Header', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [ 'name' => 'intro_heading_typography', 'label' => esc_html__( 'Heading Typography', 'onboarding-form-elementor' ), 'selector' => '{{WRAPPER}} .of-8c4c4dfe-intro-heading' ]
        );

        $this->add_control(
            'intro_heading_color',
            [
                'label'     => esc_html__( 'Heading Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-intro-heading' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [ 'name' => 'intro_desc_typography', 'label' => esc_html__( 'Description Typography', 'onboarding-form-elementor' ), 'selector' => '{{WRAPPER}} .of-8c4c4dfe-intro-desc' ]
        );

        $this->add_control(
            'intro_desc_color',
            [
                'label'     => esc_html__( 'Description Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-intro-desc' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_responsive_control(
            'intro_alignment',
            [
                'label'     => esc_html__( 'Alignment', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::CHOOSE,
                'options'   => [
                    'left'   => [ 'title' => esc_html__( 'Left', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-left' ],
                    'center' => [ 'title' => esc_html__( 'Center', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-center' ],
                    'right'  => [ 'title' => esc_html__( 'Right', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-right' ],
                ],
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-intro' => 'text-align: {{VALUE}};' ],
            ]
        );

        $this->add_responsive_control(
            'intro_spacing',
            [
                'label'      => esc_html__( 'Spacing Below', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 100 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-intro' => 'margin-bottom: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->end_controls_section();
    }

    private function register_sidebar_styles() {
        $this->start_controls_section(
            'section_style_sidebar',
            [
                'label' => esc_html__( 'Sidebar', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'sidebar_width',
            [
                'label'      => esc_html__( 'Width', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'      => [
                    'px' => [ 'min' => 150, 'max' => 500 ],
                    '%'  => [ 'min' => 10, 'max' => 50 ],
                ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-sidebar' => 'width: {{SIZE}}{{UNIT}}; flex: 0 0 {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->add_control(
            'sidebar_bg_color',
            [
                'label'     => esc_html__( 'Background Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-sidebar' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [ 'name' => 'sidebar_border', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-sidebar' ]
        );

        $this->add_responsive_control(
            'sidebar_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-sidebar' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'sidebar_padding',
            [
                'label'      => esc_html__( 'Padding', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-sidebar' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->add_control( 'sidebar_title_heading', [
            'label'     => esc_html__( 'Sidebar Title', 'onboarding-form-elementor' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [ 'name' => 'form_title_typography', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-title' ]
        );

        $this->add_control(
            'form_title_color',
            [
                'label'     => esc_html__( 'Title Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-title' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_responsive_control(
            'form_title_alignment',
            [
                'label'     => esc_html__( 'Alignment', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::CHOOSE,
                'options'   => [
                    'left'   => [ 'title' => esc_html__( 'Left', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-left' ],
                    'center' => [ 'title' => esc_html__( 'Center', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-center' ],
                    'right'  => [ 'title' => esc_html__( 'Right', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-right' ],
                ],
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-title' => 'text-align: {{VALUE}};' ],
            ]
        );

        $this->add_responsive_control(
            'form_title_spacing',
            [
                'label'      => esc_html__( 'Spacing Below', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 100 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-title' => 'margin-bottom: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->end_controls_section();
    }

    private function register_stepper_styles() {
        $this->start_controls_section(
            'section_style_stepper',
            [
                'label' => esc_html__( 'Stepper', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control( 'stepper_icon_heading', [
            'label' => esc_html__( 'Step Icon', 'onboarding-form-elementor' ),
            'type'  => \Elementor\Controls_Manager::HEADING,
        ] );

        $this->add_responsive_control(
            'step_icon_size',
            [
                'label'      => esc_html__( 'Icon Size', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [ 'px' => [ 'min' => 8, 'max' => 40 ] ],
                'selectors'  => [
                    '{{WRAPPER}} .of-8c4c4dfe-step-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .of-8c4c4dfe-step-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'step_icon_diameter',
            [
                'label'      => esc_html__( 'Diameter', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 24, 'max' => 80 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-step-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; flex-basis: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->add_control(
            'step_icon_bg_color',
            [
                'label'     => esc_html__( 'Background', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-step-icon' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'step_icon_color',
            [
                'label'     => esc_html__( 'Icon Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-step-icon' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [ 'name' => 'step_icon_border', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-step-icon' ]
        );

        $this->add_responsive_control(
            'step_icon_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-step-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->add_control( 'stepper_line_heading', [
            'label'     => esc_html__( 'Connecting Line', 'onboarding-form-elementor' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_responsive_control(
            'stepper_line_width',
            [
                'label'      => esc_html__( 'Width', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 1, 'max' => 10 ] ],
                'selectors'  => [
                    '{{WRAPPER}} .of-8c4c4dfe-stepper::before' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .of-8c4c4dfe-progress-line'   => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'stepper_line_color',
            [
                'label'     => esc_html__( 'Line Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-stepper::before' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'stepper_active_color',
            [
                'label'     => esc_html__( 'Active Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .of-8c4c4dfe-step-item.active .of-8c4c4dfe-step-icon'  => 'border-color: {{VALUE}}; color: {{VALUE}};',
                    '{{WRAPPER}} .of-8c4c4dfe-step-item.active .of-8c4c4dfe-step-title' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .of-8c4c4dfe-progress-line' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'stepper_completed_color',
            [
                'label'     => esc_html__( 'Completed Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .of-8c4c4dfe-step-item.completed .of-8c4c4dfe-step-icon' => 'background-color: {{VALUE}}; border-color: {{VALUE}}; color: #ffffff;',
                    '{{WRAPPER}} .of-8c4c4dfe-step-item.completed .of-8c4c4dfe-step-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control( 'stepper_text_heading', [
            'label'     => esc_html__( 'Step Text', 'onboarding-form-elementor' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [ 'name' => 'stepper_title_typography', 'label' => esc_html__( 'Title Typography', 'onboarding-form-elementor' ), 'selector' => '{{WRAPPER}} .of-8c4c4dfe-step-title' ]
        );

        $this->add_control(
            'stepper_title_color',
            [
                'label'     => esc_html__( 'Title Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-step-title' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [ 'name' => 'stepper_desc_typography', 'label' => esc_html__( 'Description Typography', 'onboarding-form-elementor' ), 'selector' => '{{WRAPPER}} .of-8c4c4dfe-step-desc' ]
        );

        $this->add_control(
            'stepper_desc_color',
            [
                'label'     => esc_html__( 'Description Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-step-desc' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_control( 'stepper_spacing_heading', [
            'label'     => esc_html__( 'Spacing', 'onboarding-form-elementor' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_responsive_control(
            'stepper_step_gap',
            [
                'label'      => esc_html__( 'Between Steps', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 80 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-stepper' => 'gap: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'stepper_item_gap',
            [
                'label'      => esc_html__( 'Icon to Text', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 40 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-step-item' => 'gap: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->end_controls_section();
    }

    private function register_progress_styles() {
        $this->start_controls_section(
            'section_style_progress',
            [
                'label' => esc_html__( 'Progress Indicator', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'progress_track_color',
            [
                'label'     => esc_html__( 'Track Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-top-progress' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'progress_color',
            [
                'label'     => esc_html__( 'Progress Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-top-progress-fill' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_responsive_control(
            'progress_height',
            [
                'label'      => esc_html__( 'Height', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 1, 'max' => 12 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-top-progress' => 'height: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'progress_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-top-progress, {{WRAPPER}} .of-8c4c4dfe-top-progress-fill' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'progress_spacing',
            [
                'label'      => esc_html__( 'Spacing Below', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 40 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-body' => 'padding-top: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->end_controls_section();
    }

    private function register_step_header_styles() {
        $this->start_controls_section(
            'section_style_step_header',
            [
                'label' => esc_html__( 'Step Content Header', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'pane_icon_size',
            [
                'label'      => esc_html__( 'Icon Size', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [ 'px' => [ 'min' => 12, 'max' => 64 ] ],
                'selectors'  => [
                    '{{WRAPPER}} .of-8c4c4dfe-pane-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; flex-basis: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .of-8c4c4dfe-pane-icon svg' => 'width: 60%; height: 60%;',
                ],
            ]
        );

        $this->add_control(
            'pane_icon_color',
            [
                'label'     => esc_html__( 'Icon Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-pane-icon' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'pane_icon_bg_color',
            [
                'label'     => esc_html__( 'Icon Background', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-pane-icon' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control( 'pane_counter_heading', [
            'label'     => esc_html__( 'Step Counter', 'onboarding-form-elementor' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [ 'name' => 'step_counter_typography', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-step-counter' ]
        );

        $this->add_control(
            'step_counter_color',
            [
                'label'     => esc_html__( 'Counter Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-step-counter' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_control( 'step_title_heading', [
            'label' => esc_html__( 'Step Heading', 'onboarding-form-elementor' ),
            'type'  => \Elementor\Controls_Manager::HEADING,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [ 'name' => 'pane_title_typography', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-pane-title' ]
        );

        $this->add_control(
            'pane_title_color',
            [
                'label'     => esc_html__( 'Heading Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-pane-title' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [ 'name' => 'pane_desc_typography', 'label' => esc_html__( 'Description Typography', 'onboarding-form-elementor' ), 'selector' => '{{WRAPPER}} .of-8c4c4dfe-pane-desc' ]
        );

        $this->add_control(
            'pane_desc_color',
            [
                'label'     => esc_html__( 'Description Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-pane-desc' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_responsive_control(
            'pane_header_spacing',
            [
                'label'      => esc_html__( 'Spacing Below', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 80 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-pane-header' => 'margin-bottom: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'pane_header_alignment',
            [
                'label'     => esc_html__( 'Alignment', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::CHOOSE,
                'options'   => [
                    'flex-start' => [ 'title' => esc_html__( 'Left', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-left' ],
                    'center'     => [ 'title' => esc_html__( 'Center', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-center' ],
                ],
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-pane-header' => 'justify-content: {{VALUE}};' ],
            ]
        );

        $this->end_controls_section();
    }

    private function register_fields_layout_styles() {
        // Field layout: the horizontal gap is implemented via child padding +
        // negative half-gutters on the flex row. Do not use CSS column-gap here.
        $this->start_controls_section(
            'section_style_fields',
            [
                'label' => esc_html__( 'Fields Layout', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'row_gap',
            [
                'label'      => esc_html__( 'Row Gap', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', 'rem' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 100 ] ],
                'default'    => [ 'size' => 24, 'unit' => 'px' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-fields-grid' => 'row-gap: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'column_gap',
            [
                'label'      => esc_html__( 'Column Gap', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', 'rem' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 100 ] ],
                'default'    => [ 'size' => 24, 'unit' => 'px' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-fields-grid' => '--of-8c4c4dfe-column-gap: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'fields_alignment',
            [
                'label'     => esc_html__( 'Field Alignment', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::CHOOSE,
                'options'   => [
                    'flex-start' => [ 'title' => esc_html__( 'Left', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-left' ],
                    'center'     => [ 'title' => esc_html__( 'Center', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-center' ],
                    'flex-end'   => [ 'title' => esc_html__( 'Right', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-right' ],
                ],
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-fields-grid' => 'justify-content: {{VALUE}};' ],
            ]
        );

        $this->end_controls_section();
    }

    private function register_label_styles() {
        $this->start_controls_section(
            'section_style_labels',
            [
                'label' => esc_html__( 'Labels', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [ 'name' => 'label_typography', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-label' ]
        );

        $this->add_control(
            'label_color',
            [
                'label'     => esc_html__( 'Text Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-label' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'help_text_color',
            [
                'label'     => esc_html__( 'Helper Text Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-help-text' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_responsive_control(
            'label_alignment',
            [
                'label'     => esc_html__( 'Alignment', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::CHOOSE,
                'options'   => [
                    'left'   => [ 'title' => esc_html__( 'Left', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-left' ],
                    'center' => [ 'title' => esc_html__( 'Center', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-center' ],
                    'right'  => [ 'title' => esc_html__( 'Right', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-right' ],
                ],
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-label, {{WRAPPER}} .of-8c4c4dfe-help-text' => 'text-align: {{VALUE}};' ],
            ]
        );

        $this->add_responsive_control(
            'label_margin',
            [
                'label'      => esc_html__( 'Margin', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'label_padding',
            [
                'label'      => esc_html__( 'Padding', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->end_controls_section();
    }

    private function register_input_styles() {
        $this->start_controls_section(
            'section_style_inputs',
            [
                'label' => esc_html__( 'Input Fields', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [ 'name' => 'input_typography', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-input' ]
        );

        $this->start_controls_tabs( 'tabs_input_style' );

        $this->start_controls_tab( 'tab_input_normal', [ 'label' => esc_html__( 'Normal', 'onboarding-form-elementor' ) ] );

        $this->add_control(
            'input_bg_color',
            [
                'label'     => esc_html__( 'Background Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'input_text_color',
            [
                'label'     => esc_html__( 'Text Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [ 'name' => 'input_border', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-input' ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [ 'name' => 'input_box_shadow', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-input' ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab( 'tab_input_hover', [ 'label' => esc_html__( 'Hover', 'onboarding-form-elementor' ) ] );

        $this->add_control(
            'input_hover_text_color',
            [
                'label'     => esc_html__( 'Text Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input:hover' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'input_hover_bg_color',
            [
                'label'     => esc_html__( 'Background', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input:hover' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'input_hover_border_color',
            [
                'label'     => esc_html__( 'Border Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input:hover' => 'border-color: {{VALUE}};' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [ 'name' => 'input_hover_box_shadow', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-input:hover' ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab( 'tab_input_focus', [ 'label' => esc_html__( 'Focus', 'onboarding-form-elementor' ) ] );

        $this->add_control(
            'input_focus_text_color',
            [
                'label'     => esc_html__( 'Text Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input:focus' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'input_focus_bg_color',
            [
                'label'     => esc_html__( 'Background', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input:focus' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'input_focus_border_color',
            [
                'label'     => esc_html__( 'Border Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input:focus' => 'border-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'input_focus_outline_color',
            [
                'label'     => esc_html__( 'Focus Ring Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input:focus' => 'outline: 2px solid {{VALUE}}; outline-offset: -2px;' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [ 'name' => 'input_focus_box_shadow', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-input:focus' ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab( 'tab_input_invalid', [ 'label' => esc_html__( 'Invalid', 'onboarding-form-elementor' ) ] );

        $this->add_control(
            'input_invalid_text_color',
            [
                'label'     => esc_html__( 'Text Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input.of-8c4c4dfe-input-invalid' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'input_invalid_bg_color',
            [
                'label'     => esc_html__( 'Background', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input.of-8c4c4dfe-input-invalid' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'input_invalid_border_color',
            [
                'label'     => esc_html__( 'Border Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input.of-8c4c4dfe-input-invalid' => 'border-color: {{VALUE}};' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [ 'name' => 'input_invalid_box_shadow', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-input.of-8c4c4dfe-input-invalid' ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab( 'tab_input_disabled', [ 'label' => esc_html__( 'Disabled', 'onboarding-form-elementor' ) ] );

        $this->add_control(
            'input_disabled_text_color',
            [
                'label'     => esc_html__( 'Text Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input:disabled' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'input_disabled_bg_color',
            [
                'label'     => esc_html__( 'Background', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input:disabled' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'input_disabled_border_color',
            [
                'label'     => esc_html__( 'Border Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input:disabled' => 'border-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'input_disabled_opacity',
            [
                'label'     => esc_html__( 'Opacity', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'min'       => 0,
                'max'       => 1,
                'step'      => 0.05,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input:disabled' => 'opacity: {{VALUE}};' ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_responsive_control(
            'input_padding',
            [
                'label'      => esc_html__( 'Padding', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'input_height',
            [
                'label'      => esc_html__( 'Height', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 28, 'max' => 100 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-input' => 'height: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'input_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-input' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->end_controls_section();
    }

    private function register_placeholder_styles() {
        $this->start_controls_section(
            'section_style_placeholder',
            [
                'label' => esc_html__( 'Placeholder', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [ 'name' => 'placeholder_typography', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-input::placeholder' ]
        );

        $this->add_control(
            'placeholder_color',
            [
                'label'     => esc_html__( 'Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input::placeholder' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'placeholder_opacity',
            [
                'label'     => esc_html__( 'Opacity', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'min'       => 0,
                'max'       => 1,
                'step'      => 0.05,
                'default'   => 1,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input::placeholder' => 'opacity: {{VALUE}};' ],
            ]
        );

        $this->end_controls_section();
    }

    private function register_icon_styles() {
        $this->start_controls_section(
            'section_style_icons',
            [
                'label' => esc_html__( 'Input Icons', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'input_icon_size',
            [
                'label'      => esc_html__( 'Size', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [ 'px' => [ 'min' => 8, 'max' => 40 ] ],
                'selectors'  => [
                    '{{WRAPPER}} .of-8c4c4dfe-input-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .of-8c4c4dfe-input-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'input_icon_color',
            [
                'label'     => esc_html__( 'Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-input-icon' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'input_icon_position',
            [
                'label'     => esc_html__( 'Position', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => 'left',
                'options'   => [
                    'left'  => esc_html__( 'Left', 'onboarding-form-elementor' ),
                    'right' => esc_html__( 'Right', 'onboarding-form-elementor' ),
                ],
                'prefix_class' => 'of-8c4c4dfe-icon-position-',
            ]
        );

        $this->add_responsive_control(
            'input_icon_spacing',
            [
                'label'      => esc_html__( 'Inset Spacing', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 4, 'max' => 40 ] ],
                'selectors'  => [
                    '{{WRAPPER}} .of-8c4c4dfe-icon-position-left .of-8c4c4dfe-input-icon' => 'left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .of-8c4c4dfe-icon-position-right .of-8c4c4dfe-input-icon' => 'right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    private function register_divider_styles() {
        $this->start_controls_section(
            'section_style_divider',
            [
                'label' => esc_html__( 'Divider', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'divider_color',
            [
                'label'     => esc_html__( 'Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-divider' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_responsive_control(
            'divider_width',
            [
                'label'      => esc_html__( 'Width', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'      => [ '%' => [ 'min' => 10, 'max' => 100 ], 'px' => [ 'min' => 50, 'max' => 1200 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-divider' => 'width: {{SIZE}}{{UNIT}}; margin-left: auto; margin-right: auto;' ],
            ]
        );

        $this->add_responsive_control(
            'divider_thickness',
            [
                'label'      => esc_html__( 'Thickness', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 1, 'max' => 8 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-divider' => 'height: {{SIZE}}{{UNIT}}; flex-basis: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->add_control(
            'divider_style',
            [
                'label'     => esc_html__( 'Style', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => 'solid',
                'options'   => [
                    'solid'  => esc_html__( 'Solid', 'onboarding-form-elementor' ),
                    'dashed' => esc_html__( 'Dashed', 'onboarding-form-elementor' ),
                    'dotted' => esc_html__( 'Dotted', 'onboarding-form-elementor' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .of-8c4c4dfe-divider' => 'background-color: transparent; border-top-style: {{VALUE}}; border-top-width: 1px; border-top-color: var(--ofe-divider-color, #e2e8f0);',
                ],
            ]
        );

        $this->add_responsive_control(
            'divider_spacing',
            [
                'label'      => esc_html__( 'Spacing Below', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 80 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-divider' => 'margin-bottom: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->end_controls_section();
    }

    private function register_button_styles() {
        $this->start_controls_section(
            'section_style_buttons',
            [
                'label' => esc_html__( 'Navigation Buttons', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // Shared typography base for all buttons.
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [ 'name' => 'button_typography', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-btn' ]
        );

        // ---- Back button ----
        $this->add_control( 'back_button_heading', [
            'label'     => esc_html__( 'Back Button', 'onboarding-form-elementor' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_control(
            'back_bg_color',
            [
                'label'     => esc_html__( 'Background', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-prev' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'back_text_color',
            [
                'label'     => esc_html__( 'Text Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-prev' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'back_hover_bg_color',
            [
                'label'     => esc_html__( 'Hover Background', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-prev:hover' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'back_hover_text_color',
            [
                'label'     => esc_html__( 'Hover Text', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-prev:hover' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_responsive_control(
            'back_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-btn-prev' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [ 'name' => 'back_box_shadow', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-btn-prev' ]
        );

        // ---- Next (OK) button ----
        $this->add_control( 'next_button_heading', [
            'label'     => esc_html__( 'OK / Next Button', 'onboarding-form-elementor' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->start_controls_tabs( 'tabs_next_button_style' );

        $this->start_controls_tab( 'tab_next_normal', [ 'label' => esc_html__( 'Normal', 'onboarding-form-elementor' ) ] );

        $this->add_control(
            'button_bg_color',
            [
                'label'     => esc_html__( 'Background', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-next' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label'     => esc_html__( 'Text Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-next' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [ 'name' => 'next_border', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-btn-next' ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [ 'name' => 'next_box_shadow', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-btn-next' ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab( 'tab_next_hover', [ 'label' => esc_html__( 'Hover', 'onboarding-form-elementor' ) ] );

        $this->add_control(
            'button_hover_bg_color',
            [
                'label'     => esc_html__( 'Background', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-next:hover' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'button_hover_text_color',
            [
                'label'     => esc_html__( 'Text', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-next:hover' => 'color: {{VALUE}};' ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab( 'tab_next_disabled', [ 'label' => esc_html__( 'Disabled', 'onboarding-form-elementor' ) ] );

        $this->add_control(
            'next_disabled_bg_color',
            [
                'label'     => esc_html__( 'Background', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-next:disabled' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'next_disabled_opacity',
            [
                'label'     => esc_html__( 'Opacity', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'min'       => 0,
                'max'       => 1,
                'step'      => 0.05,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-next:disabled' => 'opacity: {{VALUE}};' ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_responsive_control(
            'button_padding',
            [
                'label'      => esc_html__( 'Padding', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-btn-next' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'button_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-btn-next' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'next_button_height',
            [
                'label'      => esc_html__( 'Height', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 28, 'max' => 80 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-btn-next' => 'height: {{SIZE}}{{UNIT}};' ],
            ]
        );

        // ---- Submit button (fully independent) ----
        $this->add_control( 'submit_button_heading', [
            'label'     => esc_html__( 'Submit Button', 'onboarding-form-elementor' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->start_controls_tabs( 'tabs_submit_button_style' );

        $this->start_controls_tab( 'tab_submit_normal', [ 'label' => esc_html__( 'Normal', 'onboarding-form-elementor' ) ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [ 'name' => 'submit_typography', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-btn-submit' ]
        );

        $this->add_control(
            'submit_bg_color',
            [
                'label'     => esc_html__( 'Background Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-submit' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'submit_text_color',
            [
                'label'     => esc_html__( 'Text Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-submit' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [ 'name' => 'submit_border', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-btn-submit' ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [ 'name' => 'submit_box_shadow', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-btn-submit' ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab( 'tab_submit_hover', [ 'label' => esc_html__( 'Hover', 'onboarding-form-elementor' ) ] );

        $this->add_control(
            'submit_hover_bg_color',
            [
                'label'     => esc_html__( 'Hover Background', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-submit:hover' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'submit_hover_text_color',
            [
                'label'     => esc_html__( 'Hover Text Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-submit:hover' => 'color: {{VALUE}};' ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab( 'tab_submit_focus', [ 'label' => esc_html__( 'Focus', 'onboarding-form-elementor' ) ] );

        $this->add_control(
            'submit_focus_border_color',
            [
                'label'     => esc_html__( 'Border Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-submit:focus-visible' => 'border-color: {{VALUE}};' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [ 'name' => 'submit_focus_box_shadow', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-btn-submit:focus-visible' ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab( 'tab_submit_disabled', [ 'label' => esc_html__( 'Disabled', 'onboarding-form-elementor' ) ] );

        $this->add_control(
            'submit_disabled_bg_color',
            [
                'label'     => esc_html__( 'Background', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-submit:disabled' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'submit_disabled_opacity',
            [
                'label'     => esc_html__( 'Opacity', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::NUMBER,
                'min'       => 0,
                'max'       => 1,
                'step'      => 0.05,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-btn-submit:disabled' => 'opacity: {{VALUE}};' ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_responsive_control(
            'submit_padding',
            [
                'label'      => esc_html__( 'Padding', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-btn-submit' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'submit_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-btn-submit' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'submit_button_height',
            [
                'label'      => esc_html__( 'Height', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [ 'px' => [ 'min' => 28, 'max' => 80 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-btn-submit' => 'height: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'submit_width',
            [
                'label'      => esc_html__( 'Width', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'      => [ 'px' => [ 'min' => 60, 'max' => 600 ], '%' => [ 'min' => 10, 'max' => 100 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-btn-submit' => 'width: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'submit_alignment',
            [
                'label'     => esc_html__( 'Alignment', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::CHOOSE,
                'options'   => [
                    'flex-start' => [ 'title' => esc_html__( 'Left', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-left' ],
                    'center'     => [ 'title' => esc_html__( 'Center', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-center' ],
                    'flex-end'   => [ 'title' => esc_html__( 'Right', 'onboarding-form-elementor' ), 'icon' => 'eicon-text-align-right' ],
                ],
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-actions-right' => 'justify-content: {{VALUE}};' ],
            ]
        );

        $this->end_controls_section();
    }

    private function register_keyboard_hint_styles() {
        $this->start_controls_section(
            'section_style_keyboard_hint',
            [
                'label' => esc_html__( 'Keyboard Hint', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [ 'name' => 'keyboard_hint_typography', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-keyboard-hint' ]
        );

        $this->add_control(
            'keyboard_hint_color',
            [
                'label'     => esc_html__( 'Text Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-keyboard-hint' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'keyboard_hint_bg_color',
            [
                'label'     => esc_html__( 'Background', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-keyboard-hint kbd' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_responsive_control(
            'keyboard_hint_spacing',
            [
                'label'      => esc_html__( 'Spacing', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em' ],
                'range'      => [ 'px' => [ 'min' => 0, 'max' => 40 ] ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-keyboard-hint' => 'margin-left: {{SIZE}}{{UNIT}};' ],
            ]
        );

        $this->end_controls_section();
    }

    private function register_message_styles() {
        $this->start_controls_section(
            'section_style_messages',
            [
                'label' => esc_html__( 'Success & Error Messages', 'onboarding-form-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [ 'name' => 'message_typography', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-message' ]
        );

        $this->add_control(
            'message_success_color',
            [
                'label'     => esc_html__( 'Success Text Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-message .ofe-success' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'message_error_color',
            [
                'label'     => esc_html__( 'Error Text Color', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-message .ofe-error, {{WRAPPER}} .of-8c4c4dfe-field-error' => 'color: {{VALUE}};' ],
            ]
        );

        $this->add_control(
            'message_bg_color',
            [
                'label'     => esc_html__( 'Background', 'onboarding-form-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [ '{{WRAPPER}} .of-8c4c4dfe-message' => 'background-color: {{VALUE}};' ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [ 'name' => 'message_border', 'selector' => '{{WRAPPER}} .of-8c4c4dfe-message' ]
        );

        $this->add_responsive_control(
            'message_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-message' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'message_padding',
            [
                'label'      => esc_html__( 'Padding', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-message' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->add_responsive_control(
            'message_margin',
            [
                'label'      => esc_html__( 'Margin', 'onboarding-form-elementor' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em' ],
                'selectors'  => [ '{{WRAPPER}} .of-8c4c4dfe-message' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $fields   = isset( $settings['form_fields'] ) && is_array( $settings['form_fields'] ) ? $settings['form_fields'] : [];

        if ( empty( $fields ) ) {
            return;
        }

        $steps = $this->build_steps( $fields );

        if ( empty( $steps ) ) {
            return;
        }

        $total_steps = count( $steps );
        $email_to    = isset( $settings['email_to'] ) ? $settings['email_to'] : '';
        ?>
        <?php if ( ! empty( $settings['intro_heading'] ) || ! empty( $settings['intro_description'] ) ) : ?>
            <div class="of-8c4c4dfe-intro">
                <?php if ( ! empty( $settings['intro_heading'] ) ) : ?>
                    <h2 class="of-8c4c4dfe-intro-heading"><?php echo esc_html( $settings['intro_heading'] ); ?></h2>
                <?php endif; ?>
                <?php if ( ! empty( $settings['intro_description'] ) ) : ?>
                    <p class="of-8c4c4dfe-intro-desc"><?php echo esc_html( $settings['intro_description'] ); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="of-8c4c4dfe-wrapper of-8c4c4dfe-icon-position-left" data-total-steps="<?php echo esc_attr( $total_steps ); ?>">
            <div class="of-8c4c4dfe-top-progress" aria-hidden="true">
                <div class="of-8c4c4dfe-top-progress-fill"></div>
            </div>

            <div class="of-8c4c4dfe-body">
                <aside class="of-8c4c4dfe-sidebar">
                    <?php if ( ! empty( $settings['form_title'] ) ) : ?>
                        <h2 class="of-8c4c4dfe-title"><?php echo esc_html( $settings['form_title'] ); ?></h2>
                    <?php endif; ?>

                    <nav class="of-8c4c4dfe-stepper" aria-label="<?php echo esc_attr__( 'Form progress', 'onboarding-form-elementor' ); ?>">
                        <div class="of-8c4c4dfe-progress-line" aria-hidden="true"></div>
                        <?php foreach ( $steps as $index => $step ) : ?>
                            <div class="of-8c4c4dfe-step-item <?php echo 0 === $index ? 'active' : ''; ?>" data-step="<?php echo esc_attr( $index ); ?>">
                                <div class="of-8c4c4dfe-step-icon">
                                    <span class="of-8c4c4dfe-step-face">
                                        <?php
                                        if ( ! empty( $step['icon']['value'] ) ) {
                                            \Elementor\Icons_Manager::render_icon( $step['icon'], [ 'aria-hidden' => 'true' ] );
                                        } else {
                                            echo '<span>' . esc_html( $index + 1 ) . '</span>';
                                        }
                                        ?>
                                    </span>
                                    <svg class="of-8c4c4dfe-step-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="width:16px;height:16px"><path d="M20 6 9 17l-5-5"/></svg>
                                </div>
                                <div class="of-8c4c4dfe-step-content-meta">
                                    <div class="of-8c4c4dfe-step-title"><?php echo esc_html( $step['label'] ); ?></div>
                                    <?php if ( ! empty( $step['desc'] ) ) : ?>
                                        <div class="of-8c4c4dfe-step-desc"><?php echo esc_html( $step['desc'] ); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </nav>
                </aside>

                <div class="of-8c4c4dfe-main">
                    <?php
                    $form_args = [
                        'class'  => 'of-8c4c4dfe-form',
                        'method' => 'post',
                        'novalidate' => true,
                        'data-to' => $email_to,
                        'data-subject' => isset( $settings['email_subject'] ) ? $settings['email_subject'] : '',
                        'data-total-steps' => $total_steps,
                    ];
                    ?>
                    <form <?php
                        foreach ( $form_args as $key => $value ) {
                            echo esc_attr( $key ) . '="' . esc_attr( $value ) . '" ';
                        }
                    ?>>
                        <?php foreach ( $steps as $index => $step ) : ?>
                            <section class="of-8c4c4dfe-step-pane <?php echo 0 === $index ? 'active' : ''; ?>" data-step="<?php echo esc_attr( $index ); ?>" aria-label="<?php echo esc_attr( $step['label'] ); ?>">
                                <header class="of-8c4c4dfe-pane-header">
                                    <div class="of-8c4c4dfe-pane-icon">
                                        <?php
                                        if ( ! empty( $step['icon']['value'] ) ) {
                                            \Elementor\Icons_Manager::render_icon( $step['icon'], [ 'aria-hidden' => 'true' ] );
                                        } else {
                                            echo '<span>' . esc_html( $index + 1 ) . '</span>';
                                        }
                                        ?>
                                    </div>
                                    <div class="of-8c4c4dfe-pane-title-wrap">
                                        <p class="of-8c4c4dfe-step-counter"><?php
                                            /* translators: 1: current step, 2: total steps. */
                                            echo esc_html( sprintf( __( 'STEP %1$d OF %2$d', 'onboarding-form-elementor' ), $index + 1, $total_steps ) );
                                        ?></p>
                                        <h3 class="of-8c4c4dfe-pane-title"><?php echo esc_html( $step['label'] ); ?></h3>
                                        <?php if ( ! empty( $step['desc'] ) ) : ?>
                                            <p class="of-8c4c4dfe-pane-desc"><?php echo esc_html( $step['desc'] ); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </header>

                                <div class="of-8c4c4dfe-fields-grid">
                                    <?php foreach ( $step['fields'] as $field ) :
                                        $field_type  = isset( $field['field_type'] ) ? $field['field_type'] : 'text';
                                        $field_label = isset( $field['field_label'] ) ? $field['field_label'] : '';
                                        $help_text   = isset( $field['help_text'] ) ? $field['help_text'] : '';
                                        $placeholder = isset( $field['placeholder'] ) ? $field['placeholder'] : '';
                                        $field_icon  = isset( $field['step_icon'] ) ? $field['step_icon'] : [];
                                        $show_label  = ! isset( $field['show_label'] ) || 'yes' === $field['show_label'];
                                        $show_ph     = ! isset( $field['show_placeholder'] ) || 'yes' === $field['show_placeholder'];
                                        $show_icon   = ! isset( $field['show_icon'] ) || 'yes' === $field['show_icon'];
                                        $is_required = ! empty( $field['required'] ) && 'yes' === $field['required'];
                                        $allowed_types = [ 'text', 'email', 'tel', 'number', 'url', 'textarea' ];
                                        if ( ! in_array( $field_type, $allowed_types, true ) ) {
                                            $field_type = 'text';
                                        }
                                        $field_name = 'ofe_' . $this->make_field_key( $field );
                                        ?>
                                        <div class="of-8c4c4dfe-field-wrap <?php echo esc_attr( ! empty( $field['_id'] ) ? 'elementor-repeater-item-' . sanitize_html_class( $field['_id'] ) : '' ); ?>">
                                            <?php if ( $show_label && '' !== $field_label ) : ?>
                                                <label class="of-8c4c4dfe-label" for="<?php echo esc_attr( $field_name ); ?>"><?php echo esc_html( $field_label ); ?><?php echo $is_required ? ' <span class="of-8c4c4dfe-required" aria-hidden="true">*</span>' : ''; ?></label>
                                            <?php endif; ?>
                                            <?php if ( '' !== $help_text ) : ?>
                                                <p class="of-8c4c4dfe-help-text"><?php echo esc_html( $help_text ); ?></p>
                                            <?php endif; ?>
                                            <div class="of-8c4c4dfe-input-wrapper">
                                                <?php if ( $show_icon && ! empty( $field_icon['value'] ) ) : ?>
                                                    <span class="of-8c4c4dfe-input-icon" aria-hidden="true">
                                                        <?php \Elementor\Icons_Manager::render_icon( $field_icon, [ 'aria-hidden' => 'true' ] ); ?>
                                                    </span>
                                                <?php endif; ?>
                                                <?php if ( 'textarea' === $field_type ) : ?>
                                                    <textarea
                                                        id="<?php echo esc_attr( $field_name ); ?>"
                                                        name="<?php echo esc_attr( $field_name ); ?>"
                                                        class="of-8c4c4dfe-input"
                                                        rows="4"
                                                        data-label="<?php echo esc_attr( $field_label ); ?>"
                                                        data-type="<?php echo esc_attr( $field_type ); ?>"
                                                        <?php if ( $show_ph && '' !== $placeholder ) : ?>placeholder="<?php echo esc_attr( $placeholder ); ?>"<?php endif; ?>
                                                        <?php if ( $is_required ) : ?>required<?php endif; ?>
                                                    ></textarea>
                                                <?php else : ?>
                                                    <input
                                                        type="<?php echo esc_attr( $field_type ); ?>"
                                                        id="<?php echo esc_attr( $field_name ); ?>"
                                                        name="<?php echo esc_attr( $field_name ); ?>"
                                                        class="of-8c4c4dfe-input"
                                                        data-label="<?php echo esc_attr( $field_label ); ?>"
                                                        data-type="<?php echo esc_attr( $field_type ); ?>"
                                                        <?php if ( $show_ph && '' !== $placeholder ) : ?>placeholder="<?php echo esc_attr( $placeholder ); ?>"<?php endif; ?>
                                                        <?php if ( 'tel' === $field_type ) : ?>pattern="[0-9+()\-.\s]{6,20}"<?php endif; ?>
                                                        <?php if ( $is_required ) : ?>required<?php endif; ?>
                                                    >
                                                <?php endif; ?>
                                            </div>
                                            <p class="of-8c4c4dfe-field-error" aria-live="polite"></p>
                                        </div>
                                    <?php endforeach; ?>
                                </div>

                                <div class="of-8c4c4dfe-divider"></div>

                                <div class="of-8c4c4dfe-actions">
                                    <button type="button" class="of-8c4c4dfe-btn of-8c4c4dfe-btn-prev" aria-label="<?php echo esc_attr__( 'Back', 'onboarding-form-elementor' ); ?>"<?php echo 0 === $index ? ' hidden' : ''; ?>>
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>
                                    </button>

                                    <div class="of-8c4c4dfe-actions-right">
                                        <span class="of-8c4c4dfe-keyboard-hint"><?php echo esc_html__( 'press', 'onboarding-form-elementor' ); ?> <kbd><?php echo esc_html__( 'Enter', 'onboarding-form-elementor' ); ?></kbd> &#8629;</span>
                                        <?php if ( $index < $total_steps - 1 ) : ?>
                                            <button type="button" class="of-8c4c4dfe-btn of-8c4c4dfe-btn-next">
                                                <?php echo esc_html__( 'OK', 'onboarding-form-elementor' ); ?>
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
                                            </button>
                                        <?php else : ?>
                                            <button type="submit" class="of-8c4c4dfe-btn of-8c4c4dfe-btn-submit">
                                                <?php echo esc_html__( 'Submit', 'onboarding-form-elementor' ); ?>
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </section>
                        <?php endforeach; ?>
                        <input type="hidden" name="ofe_form_meta" value="1">
                        <div class="of-8c4c4dfe-message" role="status" aria-live="polite"></div>
                    </form>
                </div>
            </div>
        </div>
        <?php
    }

    protected function content_template() {}
}
