=== Onboarding Form for Elementor ===
Contributors: Sahin
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.2.1

A responsive multi-step onboarding form widget for Elementor.

== Installation ==
1. In WordPress, go to Plugins > Add New Plugin > Upload Plugin.
2. Upload onboarding-form-elementor.zip.
3. Activate the plugin. Elementor must also be installed and active.
4. Open Elementor and search for "Onboarding Form".
5. Add the widget and configure each field's Column Width.

== Layout fix ==
Field widths are applied to the repeater field wrapper. Horizontal spacing is created using half-gutter child padding and negative row gutters rather than flex column-gap. This prevents 50% + 50% + gap from exceeding the row width and wrapping unexpectedly.

== Notes ==
The plugin keeps the widget name and setting keys used by the supplied snippet so existing widget data is intended to remain compatible. Back up the site before replacing an existing snippet implementation. Disable the old Angie snippet after activating this plugin to avoid duplicate widget registration.
