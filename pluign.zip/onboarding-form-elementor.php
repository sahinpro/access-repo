<?php
/**
 * Plugin Name: Onboarding Form for Elementor
 * Description: A responsive multi-step onboarding form widget for Elementor, styled after the Shadcn Space "Forms 09" registration wizard.
 * Version: 2.0.0
 * Author: Custom
 * Text Domain: onboarding-form-elementor
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'OFE_VERSION', '2.0.0' );
define( 'OFE_FILE', __FILE__ );
define( 'OFE_PATH', plugin_dir_path( __FILE__ ) );
define( 'OFE_URL', plugin_dir_url( __FILE__ ) );

/** Register frontend assets before Elementor enqueues widget dependencies. */
function ofe_register_assets() {
    $css_path = OFE_PATH . 'assets/css/onboarding-form.css';
    $js_path  = OFE_PATH . 'assets/js/onboarding-form.js';

    wp_register_style(
        'onboarding-form-style-8c4c4dfe',
        OFE_URL . 'assets/css/onboarding-form.css',
        [],
        file_exists( $css_path ) ? (string) filemtime( $css_path ) : OFE_VERSION
    );

    wp_register_script(
        'onboarding-form-script-8c4c4dfe',
        OFE_URL . 'assets/js/onboarding-form.js',
        [ 'elementor-frontend', 'jquery' ],
        file_exists( $js_path ) ? (string) filemtime( $js_path ) : OFE_VERSION,
        true
    );

    wp_localize_script(
        'onboarding-form-script-8c4c4dfe',
        'OnboardingForm8c4c4dfe',
        [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'onboarding_form_nonce_8c4c4dfe' ),
        ]
    );
}
add_action( 'wp_enqueue_scripts', 'ofe_register_assets' );
add_action( 'elementor/editor/after_enqueue_scripts', 'ofe_register_assets' );

/** Register the widget with Elementor. */
function ofe_register_elementor_widget( $widgets_manager ) {
    if ( ! did_action( 'elementor/loaded' ) ) {
        return;
    }

    require_once OFE_PATH . 'includes/class-onboarding-form-widget.php';
    $widgets_manager->register( new \AngieSnippets\Onboarding_Form_8c4c4dfe() );
}
add_action( 'elementor/widgets/register', 'ofe_register_elementor_widget' );

/** Sanitize a submitted value according to its field type. */
function ofe_sanitize_field_value( $value, $type ) {
    $value = is_scalar( $value ) ? sanitize_textarea_field( (string) $value ) : '';

    switch ( $type ) {
        case 'email':
            return sanitize_email( $value );
        case 'url':
            return esc_url_raw( trim( $value ) );
        case 'number':
            return is_numeric( $value ) ? $value : '';
        case 'tel':
            return preg_replace( '/[^0-9+()\-.\s]/', '', $value );
        default:
            return $value;
    }
}

/** AJAX handler for public and logged-in form submissions. */
function ofe_handle_form_submit() {
    check_ajax_referer( 'onboarding_form_nonce_8c4c4dfe', 'nonce' );

    $raw_to = isset( $_POST['email_to'] ) ? sanitize_email( wp_unslash( $_POST['email_to'] ) ) : '';
    $to = is_email( $raw_to ) ? $raw_to : get_option( 'admin_email' );

    $subject = isset( $_POST['email_subject'] )
        ? sanitize_text_field( wp_unslash( $_POST['email_subject'] ) )
        : __( 'New Onboarding Submission', 'onboarding-form-elementor' );

    $steps = isset( $_POST['steps'] ) && is_array( $_POST['steps'] ) ? wp_unslash( $_POST['steps'] ) : [];

    $message = "New submission received:\n";

    if ( ! empty( $steps ) ) {
        // Step-grouped format: each entry carries its step label and fields.
        $message = '';
        foreach ( $steps as $step_index => $step ) {
            if ( ! is_array( $step ) ) {
                continue;
            }

            $step_label = isset( $step['label'] ) ? sanitize_text_field( $step['label'] ) : '';
            $number     = (int) $step_index + 1;
            $message   .= sprintf(
                /* translators: 1: step number, 2: step title. */
                __( "STEP %1\$d: %2\$s\n", 'onboarding-form-elementor' ),
                $number,
                $step_label
            ) . "\n";

            $field_rows = isset( $step['fields'] ) && is_array( $step['fields'] ) ? $step['fields'] : [];
            foreach ( $field_rows as $field ) {
                if ( ! is_array( $field ) || ! isset( $field['value'] ) ) {
                    continue;
                }
                $label = isset( $field['label'] ) ? sanitize_text_field( $field['label'] ) : '';
                $type  = isset( $field['type'] ) ? sanitize_key( $field['type'] ) : 'text';
                $value = ofe_sanitize_field_value( $field['value'], $type );

                if ( '' === $value && '' === $label ) {
                    continue;
                }
                $message .= $label . ': ' . $value . "\n\n";
            }
        }

        if ( '' === $message ) {
            $message = "New submission received:\n";
        }
    } else {
        // Legacy flat payload (kept for backwards compatibility).
        $submitted_fields = isset( $_POST['fields'] ) && is_array( $_POST['fields'] )
            ? wp_unslash( $_POST['fields'] )
            : [];

        foreach ( $submitted_fields as $key => $value ) {
            if ( is_scalar( $value ) ) {
                $message .= sanitize_text_field( (string) $key ) . ': ' . sanitize_text_field( (string) $value ) . "\n";
            }
        }
    }

    $sent = wp_mail( $to, $subject, $message );

    if ( $sent ) {
        wp_send_json_success( [ 'message' => __( 'Form submitted successfully!', 'onboarding-form-elementor' ) ] );
    }

    wp_send_json_error( [ 'message' => __( 'Failed to send message. Please try again.', 'onboarding-form-elementor' ) ] );
}
add_action( 'wp_ajax_onboarding_form_submit_8c4c4dfe', 'ofe_handle_form_submit' );
add_action( 'wp_ajax_nopriv_onboarding_form_submit_8c4c4dfe', 'ofe_handle_form_submit' );

/** Inform administrators when Elementor is not active. */
function ofe_elementor_missing_notice() {
    if ( ! did_action( 'elementor/loaded' ) ) {
        echo '<div class="notice notice-warning"><p>' . esc_html__( 'Onboarding Form for Elementor requires Elementor to be installed and activated.', 'onboarding-form-elementor' ) . '</p></div>';
    }
}
add_action( 'admin_notices', 'ofe_elementor_missing_notice' );
